﻿Compile using command : g++ -std=c++11 main.cpp -o main.o
			main.o

--------------------------------------------------------------------------------



The Problem is :
Min z = 2*x1 + 1*x2 + 0
 5*x1  + 10*x2  <= 50
 1*x1  + 1*x2  >= 1
 0*x1  + 1*x2  <= 4
x1 >= 0, x2 >= 0


--------------------------------------------------------------------------------



Enter number of terms in objective function
2

Enter the co-efficients of the objective function
2 1

Enter the constant value in the function:
0

Do you want to Maximize or Minimize?(1. Maximize 2. Minimize):
2

You have entered the function as follows:-

Min z = 2*x1 + 1*x2 + 0

Enter number of constraints
3

Enter the co-efficient of constraints
5 10
1 1
0 1

Enter the Condition (1. Less than  2. More than 3. Equal to):
1
2
1

Enter values of bi's
50
1
4

Enter condition for variables   (1. Greater than or equal to
                                 2. Lesser than or equal to)
1
1

Press Enter for every iteration and stop after you obtain integer solutions
